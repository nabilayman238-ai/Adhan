package com.example.adhan

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder

/** Searches the Internet Archive's public catalogue; lets you stream or save tracks for offline use. */
class ArchiveActivity : ComponentActivity() {
    private class Track(val path: String, val label: String, val size: Long)
    private var kind = "taw"
    private var title = ""
    private var presets = listOf<String>()
    private lateinit var list: ListView
    private lateinit var head: TextView
    private lateinit var box: EditText
    private var level = 0
    private var lastQuery = ""
    private var results = listOf<Pair<String, String>>()
    private var tracks = listOf<Track>()
    private var curId = ""
    private val dirName get() = when (kind) { "adhan" -> "adhan"; "hadith" -> "hadith"; else -> "taw" }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun toast(t: String) = runOnUiThread { Toast.makeText(this, t, Toast.LENGTH_LONG).show() }
    private fun localFiles() = (File(filesDir, dirName).listFiles()?.filter { it.name.endsWith(".mp3") } ?: emptyList()).sortedBy { it.name }
    private fun url(t: Track) = "https://archive.org/download/$curId/" +
        t.path.split("/").joinToString("/") { enc(it).replace("+", "%20") }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        kind = intent.getStringExtra("kind") ?: kind
        title = intent.getStringExtra("title") ?: title
        presets = intent.getStringArrayExtra("presets")?.toList() ?: emptyList()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(0xFFF4F1EA.toInt())
        }
        head = TextView(this).apply { textSize = 20f; setPadding(48, 80, 48, 16); setTextColor(0xFF0B3D2E.toInt()) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(32, 0, 32, 16) }
        box = EditText(this).apply { hint = "ابحث باسم آخر"; setSingleLine() }
        row.addView(box, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply { text = "بحث"; setOnClickListener { val q = box.text.toString().trim(); if (q.isNotEmpty()) doSearch(q) } })
        list = ListView(this)
        root.addView(head); root.addView(row)
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        showPresets()
    }

    private fun showPresets() {
        level = 0; head.text = title
        val items = presets.map { "🔎 $it" } + "📁 المحفوظ على الجهاز (${localFiles().size})"
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        list.setOnItemClickListener { _, _, pos, _ -> if (pos < presets.size) doSearch(presets[pos]) else showLocal() }
        list.onItemLongClickListener = null
    }

    private fun doSearch(q: String) {
        lastQuery = q; head.text = "جاري البحث عن: $q ..."
        Thread {
            try {
                val u = "https://archive.org/advancedsearch.php?q=" + enc("($q) AND mediatype:audio") +
                    "&fl%5B%5D=identifier&fl%5B%5D=title&rows=40&sort%5B%5D=downloads+desc&output=json"
                val docs = JSONObject(httpGet(u)).getJSONObject("response").getJSONArray("docs")
                results = (0 until docs.length()).map { val d = docs.getJSONObject(it); d.getString("identifier") to d.optString("title", d.getString("identifier")) }
                runOnUiThread { showResults() }
            } catch (e: Exception) { runOnUiThread { head.text = "تعذّر البحث، تأكد من الإنترنت" } }
        }.start()
    }

    private fun showResults() {
        level = 1
        head.text = if (results.isEmpty()) "لا توجد نتائج، جرّب اسمًا آخر" else "نتائج: $lastQuery"
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, results.map { it.second })
        list.setOnItemClickListener { _, _, pos, _ -> openItem(results[pos].first) }
        list.onItemLongClickListener = null
    }

    private fun openItem(id: String) {
        head.text = "جاري تحميل القائمة..."
        Thread {
            try {
                val files = JSONObject(httpGet("https://archive.org/metadata/$id")).getJSONArray("files")
                val l = mutableListOf<Track>()
                for (i in 0 until files.length()) {
                    val f = files.getJSONObject(i); val n = f.optString("name")
                    if (n.lowercase().endsWith(".mp3")) {
                        val mb = (f.optString("size").toLongOrNull() ?: 0L)
                        l.add(Track(n, n.substringAfterLast('/').removeSuffix(".mp3").removeSuffix(".MP3"), mb))
                    }
                }
                curId = id; tracks = l
                runOnUiThread { showTracks() }
            } catch (e: Exception) { runOnUiThread { head.text = "تعذّر فتح القائمة" } }
        }.start()
    }

    private fun showTracks() {
        level = 2
        head.text = if (tracks.isEmpty()) "لا توجد ملفات MP3 هنا" else "اختر المقطع (اضغط له: تشغيل أو تحميل)"
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            tracks.map { it.label + if (it.size > 0) "  (${it.size / 1_000_000} MB)" else "" })
        list.setOnItemClickListener { _, _, pos, _ ->
            AlertDialog.Builder(this).setTitle(tracks[pos].label)
                .setItems(arrayOf("تشغيل (إنترنت)", "حفظ للاستماع بدون إنترنت")) { _, w ->
                    if (w == 0) stream(pos) else save(pos)
                }.show()
        }
        list.onItemLongClickListener = null
    }

    private fun play(urls: List<String>, name: String) {
        ContextCompat.startForegroundService(this, Intent(this, AudioService::class.java)
            .putExtra("action", "PLAYLIST").putExtra("urls", urls.toTypedArray()).putExtra("title", name))
        toast("جاري التشغيل...")
    }

    private fun stream(pos: Int) {
        val l = if (kind != "taw") listOf(tracks[pos]) else tracks.drop(pos)
        play(l.map { url(it) }, tracks[pos].label)
    }

    private fun save(pos: Int) {
        val t = tracks[pos]; val tid = curId
        val safe = t.label.replace(Regex("[^\\p{L}\\p{N}_ -]"), "_").take(60)
        val dest = File(File(filesDir, dirName).apply { mkdirs() }, "${safe}_${System.currentTimeMillis() % 100000}.mp3")
        toast("جاري التحميل... قد يستغرق وقتًا حسب حجم الملف")
        Thread {
            try { httpDownload("https://archive.org/download/$tid/" +
                t.path.split("/").joinToString("/") { enc(it).replace("+", "%20") }, dest); toast("تم الحفظ: ${t.label}") }
            catch (e: Exception) { toast("فشل التحميل") }
        }.start()
    }

    private fun showLocal() {
        level = 3
        val files = localFiles()
        head.text = if (files.isEmpty()) "لا توجد ملفات محفوظة بعد" else "المحفوظ (اضغط للتشغيل، ومطولًا للحذف)"
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, files.map { it.name.removeSuffix(".mp3") })
        list.setOnItemClickListener { _, _, pos, _ ->
            val l = if (kind != "taw") listOf(files[pos]) else files.drop(pos)
            play(l.map { Uri.fromFile(it).toString() }, files[pos].name.removeSuffix(".mp3"))
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            AlertDialog.Builder(this).setTitle("حذف الملف؟").setPositiveButton("حذف") { _, _ -> files[pos].delete(); showLocal() }
                .setNegativeButton("إلغاء", null).show()
            true
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (level) {
            2 -> showResults()
            1, 3 -> showPresets()
            else -> super.onBackPressed()
        }
    }
}
