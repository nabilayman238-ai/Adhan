package com.example.adhan

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject

class LibraryActivity : ComponentActivity() {
    private class Entry(val label: String, val server: String, val surahs: List<Int>)
    private val entries = mutableListOf<Entry>()
    private val names = mutableMapOf<Int, String>()
    private lateinit var list: ListView
    private lateinit var head: TextView
    private var current: Entry? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(0xFFF4F1EA.toInt())
        }
        head = TextView(this).apply {
            textSize = 20f; setPadding(48, 80, 48, 32); setTextColor(0xFF0B3D2E.toInt())
            text = "جاري تحميل مكتبة المنشاوي..."
        }
        list = ListView(this)
        root.addView(head)
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        Thread { load() }.start()
    }

    private fun load() {
        try {
            val sw = JSONObject(httpGet(Config.SUWAR_API)).getJSONArray("suwar")
            for (i in 0 until sw.length()) {
                val o = sw.getJSONObject(i); names[o.getInt("id")] = o.getString("name").trim()
            }
        } catch (_: Exception) {}
        try {
            val arr = JSONObject(httpGet(Config.RECITERS_API)).getJSONArray("reciters")
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                if (!r.getString("name").contains("المنشاوي")) continue
                val ms = r.getJSONArray("moshaf")
                for (j in 0 until ms.length()) {
                    val m = ms.getJSONObject(j)
                    val server = m.getString("server").let { if (it.endsWith("/")) it else "$it/" }
                    val s = m.getString("surah_list").split(",").mapNotNull { it.trim().toIntOrNull() }
                    entries.add(Entry(r.getString("name") + " - " + m.getString("name"), server, s))
                }
            }
        } catch (_: Exception) {}
        runOnUiThread { showEntries() }
    }

    private fun showEntries() {
        current = null
        head.text = if (entries.isEmpty()) "تعذّر تحميل المكتبة، تأكد من الإنترنت" else "مكتبة المنشاوي"
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, entries.map { it.label })
        list.setOnItemClickListener { _, _, pos, _ -> showSurahs(entries[pos]) }
    }

    private fun showSurahs(e: Entry) {
        current = e
        head.text = e.label
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            e.surahs.map { "$it. سورة ${names[it] ?: ""}" })
        list.setOnItemClickListener { _, _, pos, _ ->
            val urls = e.surahs.drop(pos).map { e.server + "%03d.mp3".format(it) }.toTypedArray()
            ContextCompat.startForegroundService(this, Intent(this, AudioService::class.java)
                .putExtra("action", "PLAYLIST").putExtra("urls", urls)
                .putExtra("title", "المنشاوي - سورة ${names[e.surahs[pos]] ?: ""}"))
            Toast.makeText(this, "جاري التشغيل...", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (current != null) showEntries() else super.onBackPressed()
    }
}
