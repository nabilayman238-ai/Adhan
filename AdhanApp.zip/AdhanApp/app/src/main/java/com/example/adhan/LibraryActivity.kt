package com.example.adhan

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File

class LibraryActivity : ComponentActivity() {
    private class Entry(val label: String, val server: String, val surahs: List<Int>) {
        val key = Math.abs(label.hashCode())
    }
    private val entries = mutableListOf<Entry>()
    private val names = mutableMapOf<Int, String>()
    private lateinit var list: ListView
    private lateinit var head: TextView
    private var current: Entry? = null
    private var filter = "المنشاوي"
    private var title = "المكتبة"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        filter = intent.getStringExtra("filter") ?: filter
        title = intent.getStringExtra("title") ?: title
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(0xFFF4F1EA.toInt())
        }
        head = TextView(this).apply {
            textSize = 20f; setPadding(48, 80, 48, 32); setTextColor(0xFF0B3D2E.toInt()); text = "جاري التحميل..."
        }
        list = ListView(this)
        root.addView(head)
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        Thread { load() }.start()
    }

    private fun load() {
        try {
            val sw = JSONObject(httpGetCached(this, Config.SUWAR_API, "suwar.json")).getJSONArray("suwar")
            for (i in 0 until sw.length()) {
                val o = sw.getJSONObject(i); names[o.getInt("id")] = o.getString("name").trim()
            }
        } catch (_: Exception) {}
        try {
            val arr = JSONObject(httpGetCached(this, Config.RECITERS_API, "reciters.json")).getJSONArray("reciters")
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                if (!r.getString("name").contains(filter)) continue
                val ms = r.getJSONArray("moshaf")
                for (j in 0 until ms.length()) {
                    val m = ms.getJSONObject(j)
                    val server = m.getString("server").let { if (it.endsWith("/")) it else "$it/" }
                    val s = m.getString("surah_list").split(",").mapNotNull { it.trim().toIntOrNull() }
                    entries.add(Entry(r.getString("name") + " - " + m.getString("name"), server, s))
                }
            }
        } catch (_: Exception) {}
        runOnUiThread { showEntries() }
    }

    private fun showEntries() {
        current = null
        head.text = if (entries.isEmpty()) "تعذّر تحميل المكتبة، تأكد من الإنترنت (أول مرة فقط)" else title
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, entries.map { it.label })
        list.setOnItemClickListener { _, _, pos, _ -> showSurahs(entries[pos]) }
        list.onItemLongClickListener = null
    }

    private fun local(e: Entry, s: Int) = File(filesDir, "quran/${e.key}_$s.mp3")
    private fun lbl(e: Entry, s: Int) = (if (local(e, s).exists()) "✓ " else "") + "$s. سورة ${names[s] ?: ""}"

    private fun showSurahs(e: Entry) {
        current = e
        head.text = e.label + "\nاضغط للتشغيل، واضغط مطولًا للتحميل بدون إنترنت (✓ = محفوظة)"
        head.textSize = 16f
        val labels = e.surahs.map { lbl(e, it) }.toMutableList()
        val ad = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        list.adapter = ad
        list.setOnItemClickListener { _, _, pos, _ ->
            val urls = e.surahs.drop(pos).map {
                val f = local(e, it)
                if (f.exists()) Uri.fromFile(f).toString() else e.server + "%03d.mp3".format(it)
            }.toTypedArray()
            ContextCompat.startForegroundService(this, Intent(this, AudioService::class.java)
                .putExtra("action", "PLAYLIST").putExtra("urls", urls)
                .putExtra("title", "$filter - سورة ${names[e.surahs[pos]] ?: ""}"))
            Toast.makeText(this, "جاري التشغيل...", Toast.LENGTH_SHORT).show()
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val s = e.surahs[pos]
            val dest = local(e, s)
            if (dest.exists()) {
                Toast.makeText(this, "محفوظة بالفعل", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "جاري التحميل...", Toast.LENGTH_SHORT).show()
                Thread {
                    try {
                        dest.parentFile?.mkdirs()
                        httpDownload(e.server + "%03d.mp3".format(s), dest)
                        runOnUiThread { labels[pos] = lbl(e, s); ad.notifyDataSetChanged()
                            Toast.makeText(this, "تم التحميل", Toast.LENGTH_SHORT).show() }
                    } catch (ex: Exception) {
                        runOnUiThread { Toast.makeText(this, "فشل التحميل", Toast.LENGTH_SHORT).show() }
                    }
                }.start()
            }
            true
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (current != null) { head.textSize = 20f; showEntries() } else super.onBackPressed()
    }
}
