package com.example.adhan

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AudioService : Service() {
    private var player: ExoPlayer? = null
    private var gen = 0
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.getStringExtra("action") ?: ""
        val name = intent?.getStringExtra("name") ?: ""
        val title = when (action) {
            "ADHAN" -> "أذان $name"
            "TAWASHEEH" -> "تواشيح قبل أذان $name"
            "RADIO" -> "إذاعة القرآن الكريم"
            else -> "قرآن - المنشاوي"
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("play", "التشغيل", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "play").setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title).setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)

        val my = ++gen
        val prefs = getSharedPreferences("p", 0)
        when (action) {
            "ADHAN" -> {
                val saved = prefs.getString("adhan_uri", null)
                val id = resources.getIdentifier("adhan", "raw", packageName)
                val item = when {
                    saved != null -> MediaItem.fromUri(Uri.parse(saved))
                    id != 0 -> MediaItem.fromUri("android.resource://$packageName/$id")
                    else -> MediaItem.fromUri(Config.ADHAN_URL)
                }
                play(listOf(item), true)
            }
            "TAWASHEEH" -> {
                val saved = (prefs.getStringSet("tawasheeh_uris", emptySet()) ?: emptySet()).toList()
                val items = (saved + Config.TAWASHEEH_URLS).shuffled().map { MediaItem.fromUri(Uri.parse(it)) }
                if (items.isEmpty()) stopSelf() else play(items, false)
            }
            else -> Thread {
                val items: List<MediaItem> = try {
                    if (action == "RADIO") listOf(MediaItem.fromUri(radioUrl())) else minshawi()
                } catch (e: Exception) {
                    if (action == "RADIO") listOf(MediaItem.fromUri(Config.QURAN_RADIO_URL))
                    else Config.minshawi().map { MediaItem.fromUri(it) }
                }
                Handler(Looper.getMainLooper()).post {
                    if (my == gen) { if (items.isEmpty()) stopSelf() else play(items, false) }
                }
            }.start()
        }
        return START_NOT_STICKY
    }

    private fun fetch(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 20000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun radioUrl(): String {
        val arr = JSONObject(fetch(Config.RADIOS_API)).getJSONArray("radios")
        for (key in listOf("القاهرة", "القرآن الكريم")) {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.getString("name").contains(key)) return o.getString("url")
            }
        }
        return arr.getJSONObject(0).getString("url")
    }

    private fun minshawi(): List<MediaItem> {
        val arr = JSONObject(fetch(Config.RECITERS_API)).getJSONArray("reciters")
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            if (!r.getString("name").contains("المنشاوي")) continue
            val ms = r.getJSONArray("moshaf")
            if (ms.length() == 0) continue
            val m = ms.getJSONObject(0)
            val server = m.getString("server").let { if (it.endsWith("/")) it else "$it/" }
            return m.getString("surah_list").split(",").mapNotNull { it.trim().toIntOrNull() }
                .map { MediaItem.fromUri(server + "%03d.mp3".format(it)) }
        }
        return Config.minshawi().map { MediaItem.fromUri(it) }
    }

    private fun play(items: List<MediaItem>, alarm: Boolean) {
        player?.release()
        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(AudioAttributes.Builder()
                .setUsage(if (alarm) C.USAGE_ALARM else C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
            setWakeMode(C.WAKE_MODE_NETWORK)
            setMediaItems(items); prepare(); play()
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(s: Int) { if (s == Player.STATE_ENDED) stopSelf() }
                override fun onPlayerError(e: PlaybackException) { stopSelf() }
            })
        }
    }

    override fun onDestroy() { gen++; player?.release(); player = null; super.onDestroy() }
}
