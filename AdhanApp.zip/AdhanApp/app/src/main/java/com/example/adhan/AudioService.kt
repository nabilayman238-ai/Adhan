package com.example.adhan

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONObject
import java.io.File

class AudioService : Service() {
    private var player: ExoPlayer? = null
    private var gen = 0
    private var curTitle = ""
    private val main = Handler(Looper.getMainLooper())
    override fun onBind(i: Intent?): IBinder? = null

    private fun startFg(t: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("play", "التشغيل", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "play").setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(t).setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.getStringExtra("action") ?: ""
        val name = intent?.getStringExtra("name") ?: ""
        if (action == "HADITH" && player?.isPlaying == true) { startFg(curTitle); return START_NOT_STICKY }
        curTitle = when (action) {
            "ADHAN" -> "أذان $name"
            "TAWASHEEH" -> "تواشيح قبل أذان $name"
            "RADIO" -> "إذاعة القرآن الكريم"
            "HADITH" -> "صلِّ على النبي ﷺ"
            else -> intent?.getStringExtra("title") ?: "قرآن"
        }
        startFg(curTitle)

        val my = ++gen
        val prefs = getSharedPreferences("p", 0)
        when (action) {
            "ADHAN" -> {
                val files = (File(filesDir, "adhan").listFiles()?.filter { it.isFile && it.name.endsWith(".mp3") }
                    ?.sortedBy { it.name }) ?: emptyList()
                val idx = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء").indexOf(name).coerceAtLeast(0)
                val id = resources.getIdentifier("adhan", "raw", packageName)
                val item = when {
                    files.isNotEmpty() -> MediaItem.fromUri(Uri.fromFile(files[idx % files.size]))
                    id != 0 -> MediaItem.fromUri("android.resource://$packageName/$id")
                    else -> MediaItem.fromUri(Config.ADHAN_URL)
                }
                play(listOf(item), true)
            }
            "TAWASHEEH" -> {
                val files = (File(filesDir, "taw").listFiles()?.filter { it.isFile && it.name.endsWith(".mp3") } ?: emptyList())
                    .map { Uri.fromFile(it).toString() }
                val items = (files + Config.TAWASHEEH_URLS).shuffled().map { MediaItem.fromUri(it) }
                if (items.isEmpty()) stopSelf() else play(items, false)
            }
            "HADITH" -> {
                val files = File(filesDir, "hadith").listFiles()?.filter { it.isFile && it.name.endsWith(".mp3") } ?: emptyList()
                if (files.isEmpty()) stopSelf()
                else {
                    play(listOf(MediaItem.fromUri(Uri.fromFile(files.random()))), false)
                    // recorded clips only: stop after 2 minutes at most
                    main.postDelayed({ if (my == gen) stopSelf() }, 120_000)
                }
            }
            "PLAYLIST" -> {
                val urls = intent?.getStringArrayExtra("urls") ?: emptyArray()
                if (urls.isEmpty()) stopSelf() else play(urls.map { MediaItem.fromUri(it) }, false)
            }
            else -> Thread {
                val item = try { MediaItem.fromUri(radioUrl()) } catch (e: Exception) { MediaItem.fromUri(Config.QURAN_RADIO_URL) }
                main.post { if (my == gen) play(listOf(item), false) }
            }.start()
        }
        return START_NOT_STICKY
    }

    private fun radioUrl(): String {
        val arr = JSONObject(httpGet(Config.RADIOS_API)).getJSONArray("radios")
        for (key in listOf("القاهرة", "القرآن الكريم")) {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.getString("name").contains(key)) return o.getString("url")
            }
        }
        return arr.getJSONObject(0).getString("url")
    }

    private fun fail(msg: String?) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("err", "أخطاء", NotificationManager.IMPORTANCE_DEFAULT))
        nm.notify(3, NotificationCompat.Builder(this, "err").setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("تعذّر تشغيل الصوت").setContentText(msg ?: "خطأ غير معروف").build())
        stopSelf()
    }

    private fun play(items: List<MediaItem>, alarm: Boolean) {
        player?.release()
        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(AudioAttributes.Builder()
                .setUsage(if (alarm) C.USAGE_ALARM else C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
            setWakeMode(C.WAKE_MODE_NETWORK)
            setMediaItems(items); prepare(); play()
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(s: Int) { if (s == Player.STATE_ENDED) stopSelf() }
                override fun onPlayerError(e: PlaybackException) { fail(e.errorCodeName) }
            })
        }
    }

    override fun onDestroy() {
        gen++; player?.release(); player = null
        super.onDestroy()
    }
}
