package com.example.adhan

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer

class AudioService : Service() {
    private var player: ExoPlayer? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.getStringExtra("action") ?: ""
        val name = intent?.getStringExtra("name") ?: ""
        val title = when (action) {
            "ADHAN" -> "أذان $name"
            "TAWASHEEH" -> "تواشيح قبل أذان $name"
            "RADIO" -> "إذاعة القرآن الكريم"
            else -> "قرآن - المنشاوي"
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("play", "التشغيل", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "play").setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title).setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)

        val items: List<MediaItem> = when (action) {
            "ADHAN" -> {
                val id = resources.getIdentifier("adhan", "raw", packageName)
                if (id != 0) listOf(MediaItem.fromUri("android.resource://$packageName/$id"))
                else listOfNotNull(Config.ADHAN_URL.takeIf { it.isNotEmpty() }).map { MediaItem.fromUri(it) }
            }
            "TAWASHEEH" -> Config.TAWASHEEH_URLS.shuffled().map { MediaItem.fromUri(it) }
            "RADIO" -> listOf(MediaItem.fromUri(Config.QURAN_RADIO_URL))
            else -> Config.minshawi().map { MediaItem.fromUri(it) }
        }
        if (items.isEmpty()) { stopSelf(); return START_NOT_STICKY }
        play(items, action == "ADHAN")
        return START_NOT_STICKY
    }

    private fun play(items: List<MediaItem>, alarm: Boolean) {
        player?.release()
        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(AudioAttributes.Builder()
                .setUsage(if (alarm) C.USAGE_ALARM else C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
            setWakeMode(C.WAKE_MODE_NETWORK)
            setMediaItems(items); prepare(); play()
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(s: Int) { if (s == Player.STATE_ENDED) stopSelf() }
            })
        }
    }

    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
