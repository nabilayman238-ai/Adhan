package com.example.adhan

import android.app.NotificationChannel
import android.app.NotificationManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.media.AudioAttributes
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val type = i.getStringExtra("type") ?: return
        val name = i.getStringExtra("name") ?: ""
        when (type) {
            "ADHAN", "TAWASHEEH" -> ContextCompat.startForegroundService(
                ctx, Intent(ctx, AudioService::class.java).putExtra("action", type).putExtra("name", name))
            "SALAWAT" -> salawat(ctx)
        }
        Scheduler.scheduleAll(ctx)
    }

    private fun salawat(ctx: Context) {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (h >= 23 || h < 5) return // quiet hours
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val rawId = ctx.resources.getIdentifier("salawat", "raw", ctx.packageName)
        val ch = NotificationChannel("salawat", "الصلاة على النبي", NotificationManager.IMPORTANCE_DEFAULT)
        if (rawId != 0) ch.setSound(Uri.parse("android.resource://${ctx.packageName}/$rawId"),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build())
        nm.createNotificationChannel(ch)
        val hadith = Config.HADITH.random()
        nm.notify(2, NotificationCompat.Builder(ctx, "salawat")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("صلِّ على سيدنا محمد ﷺ")
            .setContentText(hadith).setStyle(NotificationCompat.BigTextStyle().bigText(hadith))
            .setAutoCancel(true).build())
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) { Scheduler.scheduleAll(ctx) }
}

class PrayerWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) { Scheduler.updateWidget(ctx) }
}
