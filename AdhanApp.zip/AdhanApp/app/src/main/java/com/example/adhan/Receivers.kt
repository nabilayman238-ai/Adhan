package com.example.adhan

import android.app.NotificationChannel
import android.app.NotificationManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.media.AudioAttributes
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val type = i.getStringExtra("type") ?: return
        val name = i.getStringExtra("name") ?: ""
        val sp = ctx.getSharedPreferences("p", 0)
        when (type) {
            "ADHAN" -> startAudio(ctx, "ADHAN", name)
            "TAWASHEEH" -> if (sp.getBoolean("taw_on", true)) startAudio(ctx, "TAWASHEEH", name)
            "SALAWAT" -> if (sp.getBoolean("sal_on", true)) salawat(ctx, sp.getBoolean("voice_on", true))
        }
        Scheduler.scheduleAll(ctx)
    }

    private fun startAudio(ctx: Context, action: String, name: String, text: String = "") =
        ContextCompat.startForegroundService(ctx, Intent(ctx, AudioService::class.java)
            .putExtra("action", action).putExtra("name", name).putExtra("text", text))

    private fun salawat(ctx: Context, voice: Boolean) {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (h >= 23 || h < 5) return // quiet hours
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val rawId = ctx.resources.getIdentifier("salawat", "raw", ctx.packageName)
        val ch = NotificationChannel("salawat", "الصلاة على النبي", NotificationManager.IMPORTANCE_DEFAULT)
        if (rawId != 0) ch.setSound(Uri.parse("android.resource://${ctx.packageName}/$rawId"),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build())
        nm.createNotificationChannel(ch)
        val hadith = Config.HADITH.random()
        nm.notify(2, NotificationCompat.Builder(ctx, "salawat")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("صلِّ على سيدنا محمد ﷺ")
            .setContentText(hadith).setStyle(NotificationCompat.BigTextStyle().bigText(hadith))
            .setAutoCancel(true).build())
        if (voice) startAudio(ctx, "HADITH", "",
            "اللهم صل وسلم على سيدنا محمد. " + hadith.replace("ﷺ", "صلى الله عليه وسلم"))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) { Scheduler.scheduleAll(ctx) }
}

class PrayerWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) { Scheduler.updateWidget(ctx) }
}
