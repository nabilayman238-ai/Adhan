package com.example.adhan

import android.Manifest
import android.app.AlarmManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var next: TextView

    private fun persist(u: Uri) {
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
    }

    private val pickAdhan = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            persist(u)
            getSharedPreferences("p", 0).edit().putString("adhan_uri", u.toString()).apply()
            Toast.makeText(this, "تم اختيار ملف الأذان", Toast.LENGTH_SHORT).show()
        }
    }

    private val pickTaw = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l ->
        if (l.isNotEmpty()) {
            l.forEach { persist(it) }
            getSharedPreferences("p", 0).edit().putStringSet("tawasheeh_uris", l.map { it.toString() }.toSet()).apply()
            Toast.makeText(this, "تم اختيار ${l.size} ملف تواشيح", Toast.LENGTH_SHORT).show()
        }
    }

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        Scheduler.saveLocation(this); enable()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48)
            layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_HORIZONTAL
        }
        next = TextView(this).apply { textSize = 26f; gravity = Gravity.CENTER; text = "--" }
        root.addView(TextView(this).apply { text = "الصلاة القادمة"; gravity = Gravity.CENTER })
        root.addView(next)
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        btn("تفعيل الأذان التلقائي") { start() }
        btn("تثبيت الويدجت على الشاشة") { pinWidget() }
        btn("اختيار ملف الأذان") { pickAdhan.launch(arrayOf("audio/*")) }
        btn("اختيار ملفات التواشيح") { pickTaw.launch(arrayOf("audio/*")) }
        btn("تجربة الأذان الآن") { play("ADHAN") }
        btn("إذاعة القرآن الكريم") { play("RADIO") }
        btn("قرآن - المنشاوي") { play("MINSHAWI") }
        btn("تواشيح الآن") { play("TAWASHEEH") }
        btn("إيقاف") { stopService(Intent(this, AudioService::class.java)) }
        setContentView(ScrollView(this).apply { addView(root) })
        next.text = Scheduler.nextText(this)
    }

    private fun play(a: String) =
        ContextCompat.startForegroundService(this, Intent(this, AudioService::class.java).putExtra("action", a))

    private fun pinWidget() {
        val m = AppWidgetManager.getInstance(this)
        if (m.isRequestPinAppWidgetSupported)
            m.requestPinAppWidget(ComponentName(this, PrayerWidget::class.java), null, null)
        else Toast.makeText(this, "اضغط مطولًا على الشاشة الرئيسية ثم الويدجتس ثم المؤذن", Toast.LENGTH_LONG).show()
    }

    private fun start() {
        val p = mutableListOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(p.toTypedArray())
    }

    private fun enable() {
        if (Build.VERSION.SDK_INT >= 31 && !getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            Toast.makeText(this, "فعّل إذن المنبهات الدقيقة ثم اضغط تفعيل مرة أخرى", Toast.LENGTH_LONG).show()
            return
        }
        Scheduler.scheduleAll(this)
        next.text = Scheduler.nextText(this)
        Toast.makeText(this, "تم التفعيل. استثنِ التطبيق من توفير البطارية ليعمل بثبات", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }
}
