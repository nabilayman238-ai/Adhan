package com.example.adhan

import android.Manifest
import android.app.AlarmManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val dark = 0xFF0B3D2E.toInt()
    private val green = 0xFF1C6B50.toInt()
    private val gold = 0xFFC9A24B.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var nextName: TextView
    private lateinit var nextTime: TextView
    private lateinit var countdown: TextView
    private lateinit var prayersBox: LinearLayout
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 30_000) }
    }

    private fun sp() = getSharedPreferences("p", 0)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun copyTo(u: Uri, dest: File) {
        contentResolver.openInputStream(u)?.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
    }

    private val pickAdhan = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) Thread {
            try {
                val f = File(filesDir, "adhan.mp3"); copyTo(u, f)
                sp().edit().putString("adhan_path", f.absolutePath).apply()
                runOnUiThread { toast("تم حفظ ملف الأذان"); refresh() }
            } catch (e: Exception) { runOnUiThread { toast("تعذّر نسخ الملف") } }
        }.start()
    }

    private val pickTaw = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l ->
        if (l.isNotEmpty()) Thread {
            val dir = File(filesDir, "taw"); dir.deleteRecursively(); dir.mkdirs()
            val paths = mutableSetOf<String>()
            l.forEachIndexed { i, u ->
                try { val f = File(dir, "t$i.mp3"); copyTo(u, f); paths.add(f.absolutePath) } catch (_: Exception) {}
            }
            sp().edit().putStringSet("taw_paths", paths).apply()
            runOnUiThread { toast("تم حفظ ${paths.size} ملف تواشيح"); refresh() }
        }.start()
    }

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        Scheduler.saveLocation(this); enable()
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = bg(Color.WHITE, 20)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(8), dp(16), dp(8)) }
    }

    private fun heading(t: String) = TextView(this).apply {
        text = t; textSize = 16f; setTextColor(dark); typeface = Typeface.DEFAULT_BOLD; setPadding(0, 0, 0, dp(6))
    }

    private fun btn(t: String, primary: Boolean, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 15f
        setTextColor(if (primary) Color.WHITE else dark)
        background = bg(if (primary) green else 0xFFE6EFEA.toInt(), 14)
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(48)).apply { setMargins(0, dp(4), 0, dp(4)) }
    }

    private fun sw(label: String, key: String) = Switch(this).apply {
        text = label; textSize = 15f; setPadding(0, dp(6), 0, dp(6))
        isChecked = sp().getBoolean(key, true)
        setOnCheckedChangeListener { _, c -> sp().edit().putBoolean(key, c).apply() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, 0, 0, dp(24))
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(dark, green))
                .apply { cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dp(32).toFloat(), dp(32).toFloat(), dp(32).toFloat(), dp(32).toFloat()) }
            setPadding(dp(20), dp(56), dp(20), dp(32))
        }
        header.addView(TextView(this).apply { text = "السلام عليكم ورحمة الله"; setTextColor(0xFFC9E4D6.toInt()); textSize = 14f; gravity = Gravity.CENTER })
        header.addView(TextView(this).apply { text = "الصلاة القادمة"; setTextColor(gold); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, dp(14), 0, 0) })
        nextName = TextView(this).apply { setTextColor(Color.WHITE); textSize = 38f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        nextTime = TextView(this).apply { setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.CENTER }
        countdown = TextView(this).apply { setTextColor(0xFFC9E4D6.toInt()); textSize = 15f; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) }
        header.addView(nextName); header.addView(nextTime); header.addView(countdown)
        root.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        // Today's prayers
        val c1 = card(); c1.addView(heading("مواقيت اليوم"))
        prayersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c1.addView(prayersBox); root.addView(c1)

        // Listen
        val c2 = card(); c2.addView(heading("استمع"))
        c2.addView(btn("إذاعة القرآن الكريم", true) { play("RADIO") })
        c2.addView(btn("مكتبة المنشاوي (اختر السورة)", false) { startActivity(Intent(this, LibraryActivity::class.java)) })
        c2.addView(btn("تشغيل التواشيح الآن", false) { play("TAWASHEEH") })
        c2.addView(btn("إيقاف التشغيل", false) { stopService(Intent(this, AudioService::class.java)) })
        root.addView(c2)

        // Settings
        val c3 = card(); c3.addView(heading("الإعدادات"))
        c3.addView(sw("تواشيح قبل الأذان بربع ساعة", "taw_on"))
        c3.addView(sw("الصلاة على النبي ﷺ كل نصف ساعة", "sal_on"))
        c3.addView(sw("قراءة الحديث بصوت عالٍ", "voice_on"))
        root.addView(c3)

        // Setup
        val c4 = card(); c4.addView(heading("التفعيل والصوتيات"))
        c4.addView(btn("تفعيل الأذان التلقائي", true) { start() })
        c4.addView(btn("اختيار ملف الأذان", false) { pickAdhan.launch(arrayOf("audio/*")) })
        c4.addView(btn("اختيار ملفات التواشيح", false) { pickTaw.launch(arrayOf("audio/*")) })
        c4.addView(btn("تجربة الأذان الآن", false) { play("ADHAN") })
        c4.addView(btn("اختبار التنبيه التلقائي (بعد دقيقة)", false) {
            Scheduler.scheduleTest(this)
            toast("سيؤذن بعد دقيقة. اقفل الشاشة وانتظر لتتأكد أنه يعمل في الخلفية")
        })
        c4.addView(btn("تثبيت الويدجت على الشاشة", false) { pinWidget() })
        status = TextView(this).apply { textSize = 13f; setTextColor(0xFF444444.toInt()); setPadding(0, dp(8), 0, 0) }
        c4.addView(status)
        root.addView(c4)

        setContentView(ScrollView(this).apply { setBackgroundColor(0xFFF4F1EA.toInt()); addView(root) })
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }

    private fun refresh() {
        val fmt = SimpleDateFormat("h:mm a", Locale("ar"))
        val n = Scheduler.nextPrayer(this)
        nextName.text = n?.first ?: "--"
        nextTime.text = n?.let { fmt.format(it.second) } ?: ""
        if (n != null) {
            val m = (n.second.time - System.currentTimeMillis()) / 60_000
            countdown.text = "بعد ${m / 60} ساعة و ${m % 60} دقيقة"
        }
        prayersBox.removeAllViews()
        Scheduler.day(this, 0).forEach { (name, t) ->
            val isNext = n != null && n.first == name && n.second == t
            prayersBox.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; setPadding(dp(10), dp(8), dp(10), dp(8))
                if (isNext) background = bg(0xFFE6EFEA.toInt(), 10)
                addView(TextView(context).apply {
                    text = name; textSize = 17f; setTextColor(dark)
                    if (isNext) typeface = Typeface.DEFAULT_BOLD
                }, LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(TextView(context).apply { text = fmt.format(t); textSize = 17f; setTextColor(dark) })
            })
        }
        val exact = Build.VERSION.SDK_INT < 31 || getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
        val notif = NotificationManagerCompat.from(this).areNotificationsEnabled()
        val adhanFile = sp().getString("adhan_path", null)?.let { File(it).exists() } == true
        val taw = (sp().getStringSet("taw_paths", emptySet()) ?: emptySet()).count { File(it).exists() }
        status.text = "المنبهات الدقيقة: " + (if (exact) "✓" else "✗ فعّلها") +
            "\nالإشعارات: " + (if (notif) "✓" else "✗ فعّلها") +
            "\nملف الأذان: " + (if (adhanFile) "✓ تم اختياره" else "لم يُختر (سيُستخدم رابط الإنترنت)") +
            "\nملفات التواشيح: $taw"
    }

    private fun play(a: String) =
        ContextCompat.startForegroundService(this, Intent(this, AudioService::class.java).putExtra("action", a))

    private fun pinWidget() {
        val m = AppWidgetManager.getInstance(this)
        if (m.isRequestPinAppWidgetSupported)
            m.requestPinAppWidget(ComponentName(this, PrayerWidget::class.java), null, null)
        else toast("اضغط مطولًا على الشاشة الرئيسية ثم الويدجتس ثم المؤذن")
    }

    private fun start() {
        val p = mutableListOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(p.toTypedArray())
    }

    private fun enable() {
        if (Build.VERSION.SDK_INT >= 31 && !getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            toast("فعّل إذن المنبهات الدقيقة ثم اضغط تفعيل مرة أخرى")
            return
        }
        Scheduler.scheduleAll(this)
        refresh()
        toast("تم التفعيل. استثنِ التطبيق من توفير البطارية وفعّل التشغيل التلقائي ليعمل بثبات")
        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }
}
