package com.example.adhan

object Config {
    const val FALLBACK_LAT = 30.0444   // Cairo, used until location is granted
    const val FALLBACK_LNG = 31.2357
    const val TAWASHEEH_LEAD_MIN = 15
    const val SALAWAT_EVERY_MIN = 30

    // Optional direct links for tawasheeh (you can also pick files from the phone inside the app).
    val TAWASHEEH_URLS = listOf<String>()

    // Default adhan if you did not pick a file in the app (link may change; picking a file is more reliable).
    const val ADHAN_URL = "https://archive.org/download/AdhanMisharyRashid/Adhan%20Mishary%20Rashid.mp3"

    // The app reads the live lists from the mp3quran.net API; these are only fallbacks.
    const val RADIOS_API = "https://www.mp3quran.net/api/v3/radios?language=ar"
    const val RECITERS_API = "https://www.mp3quran.net/api/v3/reciters?language=ar"
    const val SUWAR_API = "https://www.mp3quran.net/api/v3/suwar?language=ar"
    const val QURAN_RADIO_URL = "https://stream.radiojar.com/8s5u5tpdtwzuv"
    fun minshawi(): List<String> = (1..114).map { "https://server10.mp3quran.net/minsh/%03d.mp3".format(it) }

    val HADITH = listOf(
        "قال ﷺ: «إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى» (متفق عليه)",
        "قال ﷺ: «الدين النصيحة» (مسلم)",
        "قال ﷺ: «لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه» (متفق عليه)",
        "قال ﷺ: «من كان يؤمن بالله واليوم الآخر فليقل خيرًا أو ليصمت» (متفق عليه)",
        "قال ﷺ: «الكلمة الطيبة صدقة» (متفق عليه)",
        "قال ﷺ: «تبسمك في وجه أخيك لك صدقة» (الترمذي)",
        "قال ﷺ: «كلمتان خفيفتان على اللسان، ثقيلتان في الميزان، حبيبتان إلى الرحمن: سبحان الله وبحمده، سبحان الله العظيم» (متفق عليه)",
        "قال ﷺ: «من صلى علي صلاة صلى الله عليه بها عشرًا» (مسلم)",
        "قال ﷺ: «المسلم من سلم المسلمون من لسانه ويده» (متفق عليه)",
        "قال ﷺ: «الطهور شطر الإيمان» (مسلم)",
        "قال ﷺ: «اتق الله حيثما كنت، وأتبع السيئة الحسنة تمحها، وخالق الناس بخلق حسن» (الترمذي)",
        "قال ﷺ: «من سلك طريقًا يلتمس فيه علمًا سهل الله له به طريقًا إلى الجنة» (مسلم)",
        "قال ﷺ: «أحب الأعمال إلى الله أدومها وإن قل» (متفق عليه)",
        "قال ﷺ: «ليس الشديد بالصرعة، إنما الشديد الذي يملك نفسه عند الغضب» (متفق عليه)",
        "قال ﷺ: «من لا يرحم لا يرحم» (متفق عليه)",
        "قال ﷺ: «خيركم من تعلم القرآن وعلمه» (البخاري)",
        "قال ﷺ: «ما نقصت صدقة من مال» (مسلم)",
        "قال ﷺ: «من حسن إسلام المرء تركه ما لا يعنيه» (الترمذي)",
        "قال ﷺ: «أفضل الذكر لا إله إلا الله» (الترمذي)",
        "قال ﷺ: «إن الله لا ينظر إلى صوركم وأموالكم، ولكن ينظر إلى قلوبكم وأعمالكم» (مسلم)",
        "قال ﷺ: «من دل على خير فله مثل أجر فاعله» (مسلم)",
        "قال ﷺ: «إن الله كتب الإحسان على كل شيء» (مسلم)",
        "قال ﷺ: «الحياء من الإيمان» (متفق عليه)",
        "قال ﷺ: «لا تحاسدوا ولا تباغضوا ولا تدابروا، وكونوا عباد الله إخوانًا» (مسلم)",
        "قال ﷺ: «من كان في حاجة أخيه كان الله في حاجته» (متفق عليه)",
        "قال ﷺ: «الراحمون يرحمهم الرحمن، ارحموا من في الأرض يرحمكم من في السماء» (الترمذي وأبو داود)",
        "قال ﷺ: «مثل الجليس الصالح والجليس السوء كحامل المسك ونافخ الكير» (متفق عليه)",
        "قال ﷺ: «بلغوا عني ولو آية» (البخاري)",
        "قال ﷺ: «إن من أحبكم إلي وأقربكم مني مجلسًا يوم القيامة أحاسنكم أخلاقًا» (الترمذي)",
        "قال ﷺ: «اتقوا النار ولو بشق تمرة» (متفق عليه)",
        "قال ﷺ: «من صام رمضان إيمانًا واحتسابًا غفر له ما تقدم من ذنبه» (متفق عليه)",
        "قال ﷺ: «لا ضرر ولا ضرار» (ابن ماجه)",
        "قال ﷺ: «أقرب ما يكون العبد من ربه وهو ساجد، فأكثروا الدعاء» (مسلم)",
        "قال ﷺ: «من قال سبحان الله وبحمده في يوم مائة مرة حطت خطاياه وإن كانت مثل زبد البحر» (متفق عليه)",
        "قال ﷺ: «ألا أخبركم بأفضل من درجة الصيام والصلاة والصدقة؟ إصلاح ذات البين» (أبو داود والترمذي)",
        "قال ﷺ: «إذا مات ابن آدم انقطع عمله إلا من ثلاث: صدقة جارية، أو علم ينتفع به، أو ولد صالح يدعو له» (مسلم)",
        "قال ﷺ: «من يرد الله به خيرًا يفقهه في الدين» (متفق عليه)",
        "قال ﷺ: «ما ملأ آدمي وعاءً شرًّا من بطنه» (الترمذي)",
    )
}

fun httpGet(url: String): String {
    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
    c.connectTimeout = 10000; c.readTimeout = 20000
    return c.inputStream.bufferedReader().use { it.readText() }
}

fun httpGetCached(ctx: android.content.Context, url: String, name: String): String {
    val f = java.io.File(ctx.filesDir, name)
    return try { val t = httpGet(url); f.writeText(t); t } catch (e: Exception) { if (f.exists()) f.readText() else throw e }
}

fun httpDownload(url: String, dest: java.io.File) {
    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
    c.connectTimeout = 15000; c.readTimeout = 30000
    val tmp = java.io.File(dest.path + ".part")
    c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
    tmp.renameTo(dest)
}
