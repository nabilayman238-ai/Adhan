package com.example.adhan

object Config {
    const val FALLBACK_LAT = 30.0444   // Cairo, used until location is granted
    const val FALLBACK_LNG = 31.2357
    const val TAWASHEEH_LEAD_MIN = 15
    const val SALAWAT_EVERY_MIN = 30

    // Fill with direct links (or local file URIs) to recordings you have the right to use.
    val TAWASHEEH_URLS = listOf<String>(
        // "https://example.com/naqshbandi_1.mp3",
        // "https://example.com/tobar_1.mp3",
    )
    // Used only if you did not add res/raw/adhan.mp3
    const val ADHAN_URL = ""

    // Please verify these links still work.
    const val QURAN_RADIO_URL = "https://stream.radiojar.com/8s5u5tpdtwzuv"
    fun minshawi(): List<String> = (1..114).map { "https://server10.mp3quran.net/minsh/%03d.mp3".format(it) }

    val HADITH = listOf(
        "قال ﷺ: «إنما الأعمال بالنيات»",
        "قال ﷺ: «الدين النصيحة»",
        "قال ﷺ: «لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه»",
        "قال ﷺ: «من كان يؤمن بالله واليوم الآخر فليقل خيرًا أو ليصمت»",
        "قال ﷺ: «الكلمة الطيبة صدقة»",
        "قال ﷺ: «تبسمك في وجه أخيك لك صدقة»",
    )
}
