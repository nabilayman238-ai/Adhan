package com.example.adhan

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.os.Build
import android.widget.RemoteViews
import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.PrayerTimes
import com.batoulapps.adhan.data.DateComponents
import java.text.SimpleDateFormat
import java.util.*

object Scheduler {
    private val names = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")

    fun saveLocation(ctx: Context) {
        try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time } ?: return
            ctx.getSharedPreferences("p", 0).edit()
                .putFloat("lat", loc.latitude.toFloat()).putFloat("lng", loc.longitude.toFloat()).apply()
        } catch (_: SecurityException) {}
    }

    private fun coords(ctx: Context): Coordinates {
        val sp = ctx.getSharedPreferences("p", 0)
        return Coordinates(
            sp.getFloat("lat", Config.FALLBACK_LAT.toFloat()).toDouble(),
            sp.getFloat("lng", Config.FALLBACK_LNG.toFloat()).toDouble())
    }

    fun day(ctx: Context, offset: Int): List<Pair<String, Date>> {
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, offset) }
        val pt = PrayerTimes(coords(ctx), DateComponents.from(cal.time), CalculationMethod.EGYPTIAN.parameters)
        return listOf(pt.fajr, pt.dhuhr, pt.asr, pt.maghrib, pt.isha).mapIndexed { i, d -> names[i] to d }
    }

    private fun pi(ctx: Context, code: Int, type: String, name: String) = PendingIntent.getBroadcast(
        ctx, code, Intent(ctx, AlarmReceiver::class.java).putExtra("type", type).putExtra("name", name),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun scheduleAll(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) return
        val now = System.currentTimeMillis()
        val tawOn = ctx.getSharedPreferences("p", 0).getBoolean("taw_on", true)
        for (d in 0..1) day(ctx, d).forEachIndexed { i, (name, t) ->
            val adhan = t.time
            val lead = adhan - Config.TAWASHEEH_LEAD_MIN * 60_000L
            if (adhan > now) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, adhan, pi(ctx, 100 + d * 20 + i * 2, "ADHAN", name))
            if (lead > now && tawOn) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, lead, pi(ctx, 101 + d * 20 + i * 2, "TAWASHEEH", name))
        }
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, now + Config.SALAWAT_EVERY_MIN * 60_000L, pi(ctx, 1, "SALAWAT", ""))
        updateWidget(ctx)
    }

    fun nextPrayer(ctx: Context): Pair<String, Date>? {
        val now = Date()
        for (d in 0..1) for (p in day(ctx, d)) if (p.second.after(now)) return p
        return null
    }

    fun scheduleTest(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) return
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 60_000L, pi(ctx, 5, "ADHAN", "تجربة"))
    }

    fun nextText(ctx: Context): String {
        val now = Date()
        for (d in 0..1) for ((name, t) in day(ctx, d))
            if (t.after(now)) return name + "  " + SimpleDateFormat("h:mm a", Locale("ar")).format(t)
        return "--"
    }

    fun updateWidget(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, PrayerWidget::class.java))
        if (ids.isEmpty()) return
        val rv = RemoteViews(ctx.packageName, R.layout.widget).apply { setTextViewText(R.id.nextText, nextText(ctx)) }
        mgr.updateAppWidget(ids, rv)
    }
}
