Put your own audio files here (lowercase names, no spaces):
  adhan.mp3    -> the adhan audio
  salawat.mp3  -> short "salli ala sayyidna Muhammad" sound (optional, used as notification sound)
